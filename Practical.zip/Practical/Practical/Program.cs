﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Practical
{
    class Program
    {
        static void Main(string[] args)
        {
            /*
            string userInput;
            int intVal;
            double doubleVal;

            Console.Write("Enter integer value: ");
            userInput = Console.ReadLine();
            // Convert to integer type 
            intVal = Convert.ToInt32(userInput);
            Console.WriteLine("You entered {0}", intVal);

            Console.Write("Enter double value: ");
            userInput = Console.ReadLine();
            // Convert to integer type
            doubleVal = Convert.ToDouble(userInput);
            Console.WriteLine("You entered {0}", doubleVal);
            Console.ReadKey();
            */

            /*double temperature = 42.05;
            if (temperature > 32 ) {
                // start of block
                Console.WriteLine("Current temperature = {0}",temperature);
                Console.WriteLine("It's hot");
                Console.ReadKey();
                //End
            } */

            //int number = 2;
            //if (number < 5)
            //{
            //    number += 2;
            //    Console.WriteLine("{0} is less than 5", number);
            //}
            //else {
            //    number -= 2;
            //}
            //Console.WriteLine("This statement is always executed.");
            //Console.ReadKey();

            //int number = 2;
            //bool isEven;

            //isEven = (number % 2 == 0) ? true : false;
            //Console.WriteLine(isEven);
            //Console.ReadKey();
        }
    }
}
