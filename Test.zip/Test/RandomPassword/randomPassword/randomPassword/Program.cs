﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace randomPassword
{
    class Program
    {

        public static string RandomPassword(int passwordLength)
        {
            string allCharacters = "0123456789abcdefghijkmnopqrstuvwxyzABCDEFGHJKLMNOPQRSTUVWXYZ";
            Random random = new Random();
            char[] characters = new char[passwordLength];
            int allowAllCharacters = allCharacters.Length;
            for (int i = 0; i < passwordLength; i++)
            {
                characters[i] = allCharacters[(int)((allCharacters.Length) * random.NextDouble())];
            }
            return new string(characters);

        }
        static void Main(string[] args)
        {
            Console.WriteLine("Your Random Password :", RandomPassword(8));
            Console.ReadKey();
           
        }

    }
}
