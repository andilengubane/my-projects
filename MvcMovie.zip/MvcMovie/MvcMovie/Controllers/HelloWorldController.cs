﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Text.Encodings.Web;
using Microsoft.AspNetCore.Mvc;

namespace MvcMovie.Controllers
{
    public class HelloWorldController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        public string GetList(string name)
        {
            return "This is the Welcome action method...";
        }
        //GET : /HelloWorld/Welcome
        //Requires using Sysytem.Text.Encoding.Web;
        public string Welcome( string name ,int ID = 1)
        {
            //return HtmlEncoder.Default.Encode($"Hello {name} , NumTimes is : {numTimes}"); //"This is the Welcome action method...";
            return HtmlEncoder.Default.Encode($"Hello {name} , ID : {ID}");
        }
    }
}