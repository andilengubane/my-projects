﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using Microsoft.VisualBasic.FileIO;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ImportCSVFile
{
    public partial class ImportFile : Form
    {
        public ImportFile()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.DefaultExt = ".csv";
            ofd.Filter = "Comma Separated (*.csv)|*.csv";
            ofd.ShowDialog();
            textBox1.Text = ofd.FileName;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Cursor = Cursors.WaitCursor;
            DataTable imported_data = GetDataFromFile();
            if (imported_data == null) return;
            SaveImportDataToDatabase(imported_data);

            MessageBox.Show("load data succ.....!");
            textBox1.Text = string.Empty;
            Cursor = Cursors.Default;
        }
        //private static DataTable GetDataTableFromCSVFile(string csvfilePath)
        //{
        //    DataTable csvData = new DataTable();
        //    using (TextFieldParser csvReader = new TextFieldParser(csvfilePath))
        //    {
        //        csvReader.SetDelimiters(new string[] { "," });
        //        csvReader.HasFieldsEnclosedInQuotes = true;

        //        string[] colFields = csvReader.ReadFields();

        //        foreach (string column in colFields)
        //        {
        //            DataColumn datecolumn = new DataColumn(column);
        //            datecolumn.AllowDBNull = true;
        //            csvData.Columns.Add(datecolumn);
        //        }

        //        while (!csvReader.EndOfData)
        //        {
        //            string[] fieldData = csvReader.ReadFields();
        //            //Making empty value as null
        //            for (int i = 0; i < fieldData.Length; i++)
        //            {
        //                if (fieldData[i] == "")
        //                {
        //                    fieldData[i] = null;
        //                }
        //            }
        //            csvData.Rows.Add(fieldData);
        //        }
        //    }
        //    return csvData;
        //}

        private DataTable GetDataFromFile()
        {
            DataTable importedData = new DataTable();
            try
            {
                using (StreamReader sr = new StreamReader(textBox1.Text))
                {
                    string header = sr.ReadLine();
                    if (string.IsNullOrEmpty(header))
                    {
                        MessageBox.Show("no file data");
                        return null;
                    }

                    string[] headerColumns = header.Split(',');
                    foreach (string headerColumn in headerColumns)
                    {
                        importedData.Columns.Add(headerColumn);
                    }

                    while (!sr.EndOfStream)
                    {
                        string line = sr.ReadLine();
                        if (string.IsNullOrEmpty(line)) continue;
                        string[] fields = line.Split(',');
                        DataRow importedRow = importedData.NewRow();
                        for (int i = 0; i < fields.Count(); i++)
                        {
                            importedRow[i] = fields[i];
                        }
                        importedData.Rows.Add(importedRow);
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("the file could not be read:");
                Console.WriteLine(e.Message);
            }
            return importedData;
        }

        private void SaveImportDataToDatabase(DataTable imported_data)
        {
            using (SqlConnection conn = new SqlConnection("Data Source=DXJNBLP129/SQL2012;Initial Catalog=ImportFile;Integrated Security=True"))
            {
                conn.Open();
                foreach (DataRow importRow in imported_data.Rows)
                {
                    SqlCommand cmd = new SqlCommand("INSERT INTO Import ([AccountHolder],[BranchCode],[AccountNumber] "+
                                                    ",[AccountType],[TransactionDate],[Amount],[Status],[EffectiveDateStatusDate]) " +
                                                    "VALUES (@AccountHolder,@BranchCode,@AccountNumber,@AccountType,@TransactionDate" +
                                                    ",@Amount,@Status,@EffectiveDateStatusDate)", conn);
                    cmd.Parameters.AddWithValue("@AccountHolder", importRow["AccountHolder"]);
                    cmd.Parameters.AddWithValue("@BranchCode", importRow["BranchCode"]);
                    cmd.Parameters.AddWithValue("@AccountNumber", importRow["AccountNumber"]);
                    cmd.Parameters.AddWithValue("@AccountType", importRow["AccountType"]);
                    cmd.Parameters.AddWithValue("@TransactionDate", importRow["TransactionDate"]);
                    cmd.Parameters.AddWithValue("@Amount", importRow["Amount"]);
                    cmd.Parameters.AddWithValue("@Status", importRow["Status"]);
                    cmd.Parameters.AddWithValue("@EffectiveDateStatusDate", importRow["EffectiveDateStatusDate"]);
                    cmd.ExecuteNonQuery();

                }
            }
        }
    }
}

