﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace CompareCMSAndNE
{
    class Program
    {
        static void Main(string[] args)
        {
            var clientUtilitySettings = GetCMSClientUtilitySettings();
            var nonExistingSettingsNE = new List<ClientUtilitySettingModel>();
            var nonExistingSettingsCMS = new List<ClientUtilitySettingModel>();

            foreach (var item in clientUtilitySettings)
            {
                var FunctionName = item.FunctionName;
                var Name = item.Name;
                var ClientName = item.ClientName;

                var existsInNE = ExistsInNE(FunctionName, Name, ClientName);
                var strExistsInNE = existsInNE ? "Exists" : "Does Not Exist";              

                if (!existsInNE)
                {
                    if (!string.IsNullOrEmpty(Name))
                    {
                        nonExistingSettingsNE.Add(new ClientUtilitySettingModel() { ClientName = ClientName, Name = Name });
                    }
                }

                var result = string.Format("{0}\t{1}\t{2}", Name, FunctionName, strExistsInNE);
                Console.WriteLine(result);
            }


            //Checking if rhe NE client utility setting exists in CMS
            using (var context = new NotificationEngineEntities())
            {
                var ClientUtilitySettingsNE = context.ClientUtilitySettings.ToList();

                foreach (var item in ClientUtilitySettingsNE)
                {
                    var FunctionName = item.FunctionName;
                    var Name = item.Name;
                    var ClientName = item.ClientUtility.ClientName;

                    var existsInCMS = ExistsInCMS(clientUtilitySettings,FunctionName, Name, ClientName);
                    var strExistsInCMS = existsInCMS ? "Exists" : "Does Not Exist";

                    if (!existsInCMS)
                    {
                        if (!string.IsNullOrEmpty(Name))
                        {
                            nonExistingSettingsCMS.Add(new ClientUtilitySettingModel() { ClientName = ClientName, Name = Name });
                        }
                    }

                    var result = string.Format("{0}\t{1}\t{2}", Name, FunctionName, strExistsInCMS);
                    Console.WriteLine(result);
                }
            }

            Console.WriteLine("\n");
            Console.WriteLine("\n");
            Console.WriteLine("\n");
            Console.WriteLine("Non existing settings in NE");
            Console.WriteLine("----------------------------------------------------------------------------------------------");

            var index = 0;
            foreach (var item in nonExistingSettingsNE)
            {
                index++;
                var line = string.Format("{0}. Client Name: {1} \t Setting: {2}", index.ToString(), item.ClientName, item.Name);
                Console.WriteLine(line);
            }


            Console.WriteLine("\n");
            Console.WriteLine("\n");
            Console.WriteLine("\n");
            Console.WriteLine("Non existing settings in CMS");
            Console.WriteLine("----------------------------------------------------------------------------------------------");

            var index2 = 0;
            foreach (var item in nonExistingSettingsCMS)
            {
                index2++;
                var line = string.Format("{0}. Client Name: {1} \t Setting: {2}", index2.ToString(), item.ClientName, item.Name);
                Console.WriteLine(line);
            }            

            Console.ReadKey();
        }

        private static bool ExistsInNE(string FunctionName, string ClientUtilitySettingName, string ClientName)
        {
            using (var context = new NotificationEngineEntities())
            {
                var ClientUtilitySetting = context.ClientUtilitySettings.FirstOrDefault(
                        x => x.Name.Trim() == ClientUtilitySettingName.Trim()
                        && x.FunctionName == FunctionName
                        && x.ClientUtility.ClientName == ClientName);

                if (ClientUtilitySetting != null)
                    return true;
            }

            return false;
        }

        private static bool ExistsInCMS(List<ClientUtilitySettingModel> CMSClientUtilitySettings, string FunctionName, string ClientUtilitySettingName, string ClientName) 
        {
            var ClientUtilitySetting = CMSClientUtilitySettings.FirstOrDefault(
                       x => x.Name.Trim() == ClientUtilitySettingName.Trim()
                       && x.FunctionName == FunctionName
                       && x.ClientName == ClientName);
            
            if (ClientUtilitySetting != null)
                    return true;
           else
            return false;
        }
        
        private static List<ClientUtilitySettingModel> GetCMSClientUtilitySettings()
        {
            var clientUtilitySettings = new List<ClientUtilitySettingModel>();

            using (var context = new DataXchangeClientServicesEntities())
            {
                var clientUtilitiesSettings = from item in context.ClientUtilitiesSettings
                                              where item.Active
                                              select item;

                foreach (var utilitySetting in clientUtilitiesSettings)
                {
                    var xmlString = utilitySetting.SettingsXml.ToString();
                    var ClientName = utilitySetting.Client.Trim();

                    var docReader = new XmlDocument();
                    docReader.LoadXml(xmlString);

                    XmlNode utilityElement = docReader.GetElementsByTagName("utilities")[0];
                    var utilities = utilityElement.SelectNodes("utility");
                    foreach (XmlNode node in utilities)
                    {
                        var setting = node["setting"];
                        var FunctionName = node.Attributes["function"].Value;
                        var Name = setting.Attributes["name"] != null ? setting.Attributes["name"].Value : string.Empty;

                        var clientUtilitySetting = new ClientUtilitySettingModel()
                        {
                            ClientName = ClientName,
                            Name = Name,
                            FunctionName = FunctionName
                        };

                        clientUtilitySettings.Add(clientUtilitySetting);
                    }

                }
            }

            return clientUtilitySettings;

        }
    }

    public class ClientUtilitySettingModel
    {
        public string Name { get; set; }
        public string ClientName { get; set; }
        public string FunctionName { get; set; }
    }
}
